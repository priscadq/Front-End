# Desarrollador Front End - 2735 💾

Acá les voy a subir las dos clases que tenemos juntos y de paso les voy a dejar algunos links que les pueden servir!

[Ciclo de vida del componente de React](http://busypeoples.github.io/post/react-component-lifecycle/)

[Smart component y presentational component](https://medium.com/@dan_abramov/smart-and-dumb-components-7ca2f9a7c7d0)

[HOC - Higher order components](https://reactjs.org/docs/higher-order-components.html)

[Guía de estilos de Airbnb](https://github.com/airbnb/javascript/tree/master/react#basic-rules)

[El connect de Redux bien explicado](https://www.sohamkamani.com/blog/2017/03/31/react-redux-connect-explained/)

Cualquier tema que quieran profundizar tengo una vasta colección de buenos articulos en inglés y algunos en español también para pasarles 🤓 así que pueden pedirmelos por Slack.

Éxitos! 😁


