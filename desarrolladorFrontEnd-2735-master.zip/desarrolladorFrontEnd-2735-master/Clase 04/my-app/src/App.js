import React, { Component } from 'react'

import Header from './Header'

import './App.css'

class App extends Component {
  render () {
    const titles = [ 'Clase 01', 'Clase 02', 'Clase 03', 'Clase 04' ]

    return (
      <div className='App'>
        <Header titles={titles} />
      </div>
    )
  }
}

export default App
