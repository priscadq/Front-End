import React, { Component } from 'react'

import Student from './Student'

class StudentsList extends Component {
  constructor () {
    super()

    this.state = {
      showList: true
    }
  }

  handleToogleList = () => {
    const { showList } = this.state

    this.setState({
      showList: !showList
    })
  }

  render () {
    const { studentsList } = this.props

    const { showList } = this.state

    return (
      <div>
        <button onClick={this.handleToogleList}>
          {showList ? 'Ocultar' : 'Mostrar'}
        </button>
        {showList ? (
          <ul>
            {studentsList &&
              studentsList.map((student) => (
                <Student
                  key={student.dni}
                  firstName={student.firstName}
                  lastName={student.lastName}
                  dni={student.dni}
                />
              ))}
          </ul>
        ) : null}
      </div>
    )
  }
}

export default StudentsList
