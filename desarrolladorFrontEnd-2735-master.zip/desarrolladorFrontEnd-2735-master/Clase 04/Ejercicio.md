# Mostrar en pantalla un listado de alumnos

- Crear un componente que muestre en pantalla el siguiente listado de alumnos, se debe reutilizar el componente de la clase anterior.

- Agregarle tambien un botón que permita mostrar la lista o no mostrarla en pantalla.

```js
var studentsList = [
  { firstName: 'Adrián', lastName: 'Ferré' , dni: 54353353 },
  { firstName: 'Mateo', lastName: 'Molina', dni: 54533343 },
  { firstName: 'Maria', lastName: 'Fernandez',dni: 54353512 },
  { firstName: 'Diego', lastName: 'Forti', dni: 54533843 },
  { firstName: 'Agustín', lastName: 'Quevedo',dni: 54357512 }
]
```

