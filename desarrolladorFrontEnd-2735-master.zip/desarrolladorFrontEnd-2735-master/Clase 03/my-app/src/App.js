import React, { Component } from 'react'
import Student from './Student'
import './App.css'

import Header from './Header'

const ajaxCall = {
  title: 'Clase 03',
  subtitle: 'Clase de los Sábados'
}

const ajaxCall2 = {
  studentAjax: {
    firstName: 'Juan',
    lastName: 'Perez',
    dni: '56567567'
  }
}

class App extends Component {
  render () {
    const { title, subtitle } = ajaxCall

    const { studentAjax } = ajaxCall2

    // let student = null

    // if (studentAjax) {
    //   student = (
    //     <Student
    //       firstName={studentAjax.firstName}
    //       lastName={studentAjax.lastName}
    //       dni={studentAjax.dni}
    //     />
    //   )
    // }

    return (
      <div className='App'>
        <p className='App-intro'>
          To get started, edit <code>src/App.js</code> and save to reload.
        </p>
        {studentAjax ? (
          <Student
            firstName={studentAjax.firstName}
            lastName={studentAjax.lastName}
            dni={studentAjax.dni}
          />
        ) : null}
      </div>
    )
  }
}

export default App
