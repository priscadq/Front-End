import React, { Component } from 'react'

import './App.css'

import StudentsList from './StudentsList'

var studentsList = [
  { firstName: 'Adrián', lastName: 'Ferré', dni: 54353353 },
  { firstName: 'Mateo', lastName: 'Molina', dni: 54533343 },
  { firstName: 'Maria', lastName: 'Fernandez', dni: 54353512 },
  { firstName: 'Diego', lastName: 'Forti', dni: 54533843 },
  { firstName: 'Agustín', lastName: 'Quevedo', dni: 54357512 }
]

class App extends Component {
  render () {
    return (
      <div className='App'>
        <StudentsList studentsList={studentsList} />
      </div>
    )
  }
}

export default App
