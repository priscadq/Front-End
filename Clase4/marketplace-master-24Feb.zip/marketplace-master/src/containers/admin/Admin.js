import React, { Component } from 'react';

export default class Admin extends Component {
    render() {
        return (
            <div>
            This is Admin page.
            </div>
        );
    }
}