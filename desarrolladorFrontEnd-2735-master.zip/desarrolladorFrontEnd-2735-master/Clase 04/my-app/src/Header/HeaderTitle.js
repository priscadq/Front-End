import React from 'react'

function HeaderTitle ({ title }) {
  return <h1 className='App-title'>{title}</h1>
}

export default HeaderTitle
