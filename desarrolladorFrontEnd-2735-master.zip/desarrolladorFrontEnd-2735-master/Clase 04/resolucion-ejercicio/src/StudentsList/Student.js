import React from 'react'

function Student ({ firstName, lastName, dni }) {
  return (
    <li>
      <h1>{firstName}</h1>
      <h3>{lastName}</h3>
      <h6>{dni}</h6>
    </li>
  )
}

export default Student
