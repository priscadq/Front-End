import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import PostList from './components/PostList';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      posts: [],
      postDescription: ''
    };
    // Handlers
    this.handleDelete = this.handleDelete.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  componentDidMount() {
    fetch('https://react-demo-api.herokuapp.com/posts')
      .then(res => res.json())
      .then(results => {
        this.setState({
          posts: results
        });
      });
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <div className="App-intro">
          <form onSubmit={this.handleSave}>
            <input type="text" onChange={this.handleChange} value={this.state.postDescription} /><button type="submit">Save</button>
          </form>
          <PostList posts={this.state.posts} deletePost={this.handleDelete} />
        </div>
      </div>
    );
  }
  handleDelete(id) {
    fetch(`https://react-demo-api.herokuapp.com/posts/${id}`, {
      method: 'DELETE'
    })
      .then(res => res.json())
      .then(result => {
        this.setState({
          posts: this.state.posts.filter(p => p.id !== id)
        })
      });
  }
  handleChange(e) {
    this.setState({
      postDescription: e.target.value
    });
  }
  handleSave(e) {
    // Previen comportamiento por defecto 
    // de enviar informacion al servidor 
    // y resetear el formulario
    e.preventDefault();
    fetch(
      'https://react-demo-api.herokuapp.com/posts/',
      {
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify({
          description: this.state.postDescription
        })
      }
    )
      .then(res => res.json())
      .then(createdPost => {
        this.setState((prevState) => ({
          posts: prevState.posts.concat(
            {
              id: createdPost.id,
              description: this.state.postDescription
            }),
          postDescription: ''
        }));
      });
  }
}

export default App;
