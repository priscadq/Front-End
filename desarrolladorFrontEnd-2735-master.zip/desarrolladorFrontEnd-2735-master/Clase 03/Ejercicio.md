# Crear mi primer componente

- Crear un componente Student que reciba como propiedades `firstName`, `lastName` y `dni`, y los muestre en pantalla.

- Extra: Jugar un poco poniendole estilos al componente para que se vea copado 🎨